package com.example.flutter_exp8

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
