import 'package:flutter/material.dart';

void main() {
  runApp(const GoodHabitsApp());
}

class GoodHabitsApp extends StatelessWidget {
  const GoodHabitsApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Good Habits',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.greenAccent),
      ),
      home: const HabitListPage(),
    );
  }
}

class HabitListPage extends StatelessWidget {
  const HabitListPage({super.key});

  final List<Map<String, dynamic>> habits = const [
    {'title': 'Wake up early', 'desc': 'Start your day before 6 AM'},
    {'title': 'Read 10 pages', 'desc': 'Feed your mind daily'},
    {'title': 'Drink water', 'desc': 'Stay hydrated and alert'},
    {'title': 'Exercise 30 mins', 'desc': 'Move your body to stay strong'},
    {'title': 'Journal your thoughts', 'desc': 'Reflect and stay grounded'},
    {'title': 'Avoid phone at meals', 'desc': 'Be present with your food'},
    {'title': 'Sleep before 11 PM', 'desc': 'Recover and refresh your mind'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Good Habits'),
        centerTitle: true,
        backgroundColor: Colors.greenAccent.shade700,
      ),
      body: ListView.builder(
        itemCount: habits.length,
        padding: const EdgeInsets.all(10),
        itemBuilder: (context, index) {
          final habit = habits[index];
          return Card(
            color: Colors.greenAccent.shade100,
            margin: const EdgeInsets.symmetric(vertical: 8),
            elevation: 3,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.greenAccent.shade700,
                child: Text('${index + 1}', style: const TextStyle(color: Colors.white)),
              ),
              title: Text(
                habit['title'],
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              subtitle: Text(
                habit['desc'],
                style: const TextStyle(color: Colors.black87),
              ),
            ),
          );
        },
      ),
    );
  }
}
