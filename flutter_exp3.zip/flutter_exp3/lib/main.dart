// lib/main.dart
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HabitListScreen(),
    );
  }
}

class HabitListScreen extends StatefulWidget {
  const HabitListScreen({super.key});
  @override
  State<HabitListScreen> createState() => _HabitListScreenState();
}

class _HabitListScreenState extends State<HabitListScreen> {
  // initial list of habits
  final List<Map<String, dynamic>> _habits = [
    {
      "title": "Wake up early",
      "subtitle": "Start your day before 6 AM",
      "frequency": "Daily",
      "done": false,
      "emoji": "🌅"
    },
    {
      "title": "Read 10 pages",
      "subtitle": "Feed your mind daily",
      "frequency": "Daily",
      "done": false,
      "emoji": "📚"
    },
    {
      "title": "Drink water",
      "subtitle": "Drink at least 3L",
      "frequency": "Daily",
      "done": false,
      "emoji": "💧"
    },
    {
      "title": "Exercise 30 mins",
      "subtitle": "Move your body and stay strong",
      "frequency": "4x/week",
      "done": false,
      "emoji": "🏃"
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Good Habits'),
        backgroundColor: Colors.blueGrey,
      ),
      body: _habits.isEmpty
          ? const Center(
              child: Text('No habits available',
                  style: TextStyle(fontSize: 18, color: Colors.grey)))
          : ListView.separated(
              padding: const EdgeInsets.all(8),
              itemCount: _habits.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, index) {
                final habit = _habits[index];
                final done = habit['done'] as bool;
                return ListTile(
                  onTap: () => _showDetailsDialog(context, habit),
                  leading: CircleAvatar(
                    radius: 26,
                    backgroundColor: done ? Colors.green.shade200 : Colors.blueGrey.shade100,
                    child: Text(
                      habit['emoji'] ?? habit['title'][0],
                      style: const TextStyle(fontSize: 20),
                    ),
                  ),
                  title: Text(
                    habit["title"],
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      decoration: done ? TextDecoration.lineThrough : null,
                    ),
                  ),
                  subtitle: Text(habit["subtitle"]),
                  trailing: SizedBox(
                    width: 120,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          habit["frequency"],
                          style: TextStyle(
                            color: done ? Colors.green.shade700 : Colors.blue,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 6),
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            minimumSize: const Size(80, 32),
                            backgroundColor: done ? Colors.green : null,
                          ),
                          onPressed: () => _toggleComplete(context, index),
                          child: Text(
                            done ? "Undo" : "Complete",
                            style: const TextStyle(fontSize: 12),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showAddHabitDialog,
        child: const Icon(Icons.add),
        tooltip: 'Add habit',
      ),
    );
  }

  void _toggleComplete(BuildContext context, int index) {
    setState(() {
      _habits[index]['done'] = !_habits[index]['done'];
    });

    final title = _habits[index]['title'];
    final done = _habits[index]['done'] as bool;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(done ? '"$title" marked complete!' : '"$title" marked not done.'),
        duration: const Duration(seconds: 1),
      ),
    );
  }

  void _showDetailsDialog(BuildContext context, Map<String, dynamic> habit) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Text(habit['emoji'] ?? ''),
            const SizedBox(width: 8),
            Expanded(child: Text(habit['title'])),
          ],
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(habit['subtitle']),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.calendar_today, size: 18),
                const SizedBox(width: 6),
                Text('Frequency: ${habit['frequency']}'),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Icon(Icons.check_circle_outline, size: 18),
                const SizedBox(width: 6),
                Text(habit['done'] ? 'Status: Done' : 'Status: Not done'),
              ],
            )
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
        ],
      ),
    );
  }

  void _showAddHabitDialog() {
    final titleCtl = TextEditingController();
    final subtitleCtl = TextEditingController();
    final freqCtl = TextEditingController(text: 'Daily');
    final emojiCtl = TextEditingController(text: '✨');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Add Habit'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(controller: titleCtl, decoration: const InputDecoration(labelText: 'Title')),
              TextField(controller: subtitleCtl, decoration: const InputDecoration(labelText: 'Subtitle')),
              TextField(controller: freqCtl, decoration: const InputDecoration(labelText: 'Frequency')),
              TextField(controller: emojiCtl, decoration: const InputDecoration(labelText: 'Emoji (optional)')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Cancel')),
          ElevatedButton(
            onPressed: () {
              final title = titleCtl.text.trim();
              if (title.isEmpty) return;
              setState(() {
                _habits.insert(0, {
                  'title': title,
                  'subtitle': subtitleCtl.text.trim().isEmpty ? 'Build this habit' : subtitleCtl.text.trim(),
                  'frequency': freqCtl.text.trim().isEmpty ? 'Daily' : freqCtl.text.trim(),
                  'done': false,
                  'emoji': emojiCtl.text.trim().isEmpty ? '✨' : emojiCtl.text.trim(),
                });
              });
              Navigator.of(ctx).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Added "$title"'), duration: const Duration(seconds: 1)),
              );
            },
            child: const Text('Add'),
          ),
        ],
      ),
    );
  }
}
