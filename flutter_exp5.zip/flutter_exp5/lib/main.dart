// lib/main.dart
import 'package:flutter/material.dart';
import 'habit_time_model.dart';

void main() => runApp(const HabitExpApp());

class HabitExpApp extends StatelessWidget {
  const HabitExpApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Experiment 5 — Habit Time Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal)),
      routes: {
        '/': (c) => const MainShell(),
        '/result': (c) => const HabitResultScreen(),
      },
      initialRoute: '/',
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _selectedIndex = 0;
  HabitTimePlan? _lastPlan;
  late List<Widget> _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = [
      const HabitsHomeScreen(),
      AddHabitTimeScreen(onSubmit: _onPlanSubmitted),
      Builder(builder: (c) => ReportTab(lastPlan: _lastPlan)),
    ];
  }

  void _onPlanSubmitted(HabitTimePlan plan) {
    setState(() {
      _lastPlan = plan;
      _tabs[2] = ReportTab(lastPlan: _lastPlan);
      _selectedIndex = 2;
    });
    Navigator.of(context).pushNamed('/result', arguments: plan);
  }

  void _onTap(int idx) => setState(() => _selectedIndex = idx);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _selectedIndex, children: _tabs),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onTap,
        selectedItemColor: Colors.teal.shade700,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.list), label: 'Habits'),
          BottomNavigationBarItem(icon: Icon(Icons.add_circle_outline), label: 'Add Habit Time'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: 'Report'),
        ],
      ),
    );
  }
}

class HabitsHomeScreen extends StatelessWidget {
  const HabitsHomeScreen({super.key});
  final List<Map<String, String>> _habits = const [
    {'title': 'Wake up early', 'desc': 'Start day before 6 AM'},
    {'title': 'Read daily', 'desc': '10 pages minimum'},
    {'title': 'Hydration', 'desc': 'Drink water regularly'},
    {'title': 'Exercise', 'desc': 'Move 30 minutes'},
    {'title': 'Journal', 'desc': 'Reflect for 5-10 minutes'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Good Habits'),
        centerTitle: true,
        backgroundColor: Colors.teal,
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(12),
        itemCount: _habits.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) {
          final h = _habits[i];
          return Card(
            elevation: 2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.teal.shade100,
                child: Text('${i + 1}'),
              ),
              title: Text(h['title']!, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(h['desc']!),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
              onTap: () {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Try adding time for "${h['title']}" in Add Habit Time tab')),
                );
              },
            ),
          );
        },
      ),
    );
  }
}

class AddHabitTimeScreen extends StatefulWidget {
  final void Function(HabitTimePlan) onSubmit;
  const AddHabitTimeScreen({super.key, required this.onSubmit});

  @override
  State<AddHabitTimeScreen> createState() => _AddHabitTimeScreenState();
}

class _AddHabitTimeScreenState extends State<AddHabitTimeScreen> {
  final _formKey = GlobalKey<FormState>();
  final _monthly = TextEditingController(text: '1200'); // example default
  final _aMinutes = TextEditingController(text: '10');
  final _aSessions = TextEditingController(text: '5');
  final _bMinutes = TextEditingController(text: '15');
  final _bSessions = TextEditingController(text: '3');
  final _cMinutes = TextEditingController(text: '20');
  final _cSessions = TextEditingController(text: '2');
  final _other = TextEditingController(text: '0');

  @override
  void dispose() {
    _monthly.dispose();
    _aMinutes.dispose();
    _aSessions.dispose();
    _bMinutes.dispose();
    _bSessions.dispose();
    _cMinutes.dispose();
    _cSessions.dispose();
    _other.dispose();
    super.dispose();
  }

  String? _validateNumber(String? v, {bool allowZero = true}) {
    if (v == null || v.trim().isEmpty) return 'Enter value';
    final n = double.tryParse(v);
    if (n == null || (!allowZero && n <= 0) || n < 0) return 'Enter a valid number';
    return null;
  }

  String? _validateInt(String? v) {
    if (v == null || v.trim().isEmpty) return 'Enter value';
    final n = int.tryParse(v);
    if (n == null || n < 0) return 'Enter a valid whole number';
    return null;
  }

  void _submit() {
    if (!_formKey.currentState!.validate()) return;
    final plan = HabitTimePlan(
      monthlyMinutes: double.parse(_monthly.text.trim()),
      habitA_minutesPerSession: double.parse(_aMinutes.text.trim()),
      habitA_sessionsPerWeek: int.parse(_aSessions.text.trim()),
      habitB_minutesPerSession: double.parse(_bMinutes.text.trim()),
      habitB_sessionsPerWeek: int.parse(_bSessions.text.trim()),
      habitC_minutesPerSession: double.parse(_cMinutes.text.trim()),
      habitC_sessionsPerWeek: int.parse(_cSessions.text.trim()),
      otherMonthlyMinutes: double.parse(_other.text.trim()),
    );
    widget.onSubmit(plan);
  }

  Widget _minutesField(TextEditingController ctl, String label, {String hint = 'minutes'}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextFormField(
        controller: ctl,
        validator: (v) => _validateNumber(v, allowZero: v == '0' ? true : true),
        keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: false),
        decoration: InputDecoration(labelText: label, hintText: hint, border: const OutlineInputBorder()),
      ),
    );
  }

  Widget _sessionsField(TextEditingController ctl, String label, {String hint = 'sessions/week'}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: TextFormField(
        controller: ctl,
        validator: _validateInt,
        keyboardType: const TextInputType.numberWithOptions(decimal: false, signed: false),
        decoration: InputDecoration(labelText: label, hintText: hint, border: const OutlineInputBorder()),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Habit Time'),
        backgroundColor: Colors.teal,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(14),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _minutesField(_monthly, 'Monthly available time (min)', hint: 'Total minutes you can allocate this month'),
              const SizedBox(height: 6),
              const Divider(),
              const SizedBox(height: 6),
              const Align(alignment: Alignment.centerLeft, child: Text('Habit A', style: TextStyle(fontWeight: FontWeight.bold))),
              _minutesField(_aMinutes, 'Minutes per session (Habit A)'),
              _sessionsField(_aSessions, 'Sessions per week (Habit A)'),
              const SizedBox(height: 8),
              const Align(alignment: Alignment.centerLeft, child: Text('Habit B', style: TextStyle(fontWeight: FontWeight.bold))),
              _minutesField(_bMinutes, 'Minutes per session (Habit B)'),
              _sessionsField(_bSessions, 'Sessions per week (Habit B)'),
              const SizedBox(height: 8),
              const Align(alignment: Alignment.centerLeft, child: Text('Habit C', style: TextStyle(fontWeight: FontWeight.bold))),
              _minutesField(_cMinutes, 'Minutes per session (Habit C)'),
              _sessionsField(_cSessions, 'Sessions per week (Habit C)'),
              const SizedBox(height: 8),
              _minutesField(_other, 'Other monthly minutes', hint: 'minutes already allocated monthly'),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _submit,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.teal.shade700),
                child: const Padding(padding: EdgeInsets.all(12), child: Text('Submit Plan')),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HabitResultScreen extends StatelessWidget {
  const HabitResultScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)!.settings.arguments;
    if (args == null || args is! HabitTimePlan) {
      return Scaffold(
        appBar: AppBar(title: const Text('Habit Report'), backgroundColor: Colors.teal),
        body: const Center(child: Text('No plan submitted yet. Submit one from Add Habit Time tab.')),
      );
    }
    final plan = args;
    final usedA = plan.habitA_monthly;
    final usedB = plan.habitB_monthly;
    final usedC = plan.habitC_monthly;
    final other = plan.otherMonthlyMinutes;
    final totalUsed = plan.totalUsedMonthly;
    final remaining = plan.remainingMonthly;
    final ok = remaining >= 0;

    return Scaffold(
      appBar: AppBar(title: const Text('Habit Report'), backgroundColor: Colors.teal),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            _tile(Icons.timer, 'Monthly available (min)', plan.monthlyMinutes),
            _tile(Icons.check, 'Habit A monthly total (min)', usedA),
            _tile(Icons.check, 'Habit B monthly total (min)', usedB),
            _tile(Icons.check, 'Habit C monthly total (min)', usedC),
            _tile(Icons.more_time, 'Other monthly minutes', other),
            const SizedBox(height: 12),
            Card(
              elevation: 3,
              child: ListTile(
                leading: Icon(ok ? Icons.thumb_up : Icons.warning, color: ok ? Colors.green : Colors.red),
                title: const Text('Remaining time (min)'),
                subtitle: Text(remaining.toStringAsFixed(1), style: TextStyle(color: ok ? Colors.green : Colors.red, fontSize: 18)),
                trailing: Text(ok ? 'Enough time' : 'Over-allocated', style: TextStyle(color: ok ? Colors.green : Colors.red, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              color: Colors.teal.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('Quick advice', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(
                    ok
                        ? 'Your plan fits the monthly time you provided. Keep the schedule consistent: small sustained sessions beat rare long bursts.'
                        : 'You have allocated more minutes than available. Options: reduce sessions-per-week, shorten sessions by 25–50%, or lower number of habits for now.',
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tile(IconData icon, String title, double value) => Card(
        elevation: 1,
        margin: const EdgeInsets.symmetric(vertical: 6),
        child: ListTile(
          leading: Icon(icon, color: Colors.teal),
          title: Text(title),
          subtitle: Text(value.toStringAsFixed(1)),
        ),
      );
}

class ReportTab extends StatelessWidget {
  final HabitTimePlan? lastPlan;
  const ReportTab({super.key, required this.lastPlan});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Last Report'), backgroundColor: Colors.teal),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: lastPlan == null
            ? const Center(child: Text('No plan submitted yet. Add one via Add Habit Time tab.'))
            : HabitSummaryView(plan: lastPlan!),
      ),
    );
  }
}

class HabitSummaryView extends StatelessWidget {
  final HabitTimePlan plan;
  const HabitSummaryView({super.key, required this.plan});

  @override
  Widget build(BuildContext context) {
    final usedA = plan.habitA_monthly;
    final usedB = plan.habitB_monthly;
    final usedC = plan.habitC_monthly;
    final other = plan.otherMonthlyMinutes;
    final used = plan.totalUsedMonthly;
    final remaining = plan.remainingMonthly;
    final ok = remaining >= 0;

    return ListView(
      children: [
        ListTile(title: const Text('Monthly minutes'), trailing: Text(plan.monthlyMinutes.toStringAsFixed(1))),
        const Divider(),
        ListTile(
          title: const Text('Habit A monthly'),
          subtitle: Text('${plan.habitA_minutesPerSession} min · ${plan.habitA_sessionsPerWeek} sessions/week'),
          trailing: Text(usedA.toStringAsFixed(1)),
        ),
        ListTile(
          title: const Text('Habit B monthly'),
          subtitle: Text('${plan.habitB_minutesPerSession} min · ${plan.habitB_sessionsPerWeek} sessions/week'),
          trailing: Text(usedB.toStringAsFixed(1)),
        ),
        ListTile(
          title: const Text('Habit C monthly'),
          subtitle: Text('${plan.habitC_minutesPerSession} min · ${plan.habitC_sessionsPerWeek} sessions/week'),
          trailing: Text(usedC.toStringAsFixed(1)),
        ),
        ListTile(title: const Text('Other (monthly)'), trailing: Text(other.toStringAsFixed(1))),
        const SizedBox(height: 12),
        Card(
          elevation: 2,
          child: ListTile(
            leading: Icon(ok ? Icons.check_circle : Icons.warning, color: ok ? Colors.green : Colors.red),
            title: const Text('Remaining minutes'),
            trailing: Text(remaining.toStringAsFixed(1), style: TextStyle(color: ok ? Colors.green : Colors.red)),
          ),
        ),
        const SizedBox(height: 12),
        ElevatedButton(
          onPressed: () {
            Navigator.of(context).pushNamed('/result', arguments: plan);
          },
          child: const Text('Open Detailed Report'),
        ),
      ],
    );
  }
}
