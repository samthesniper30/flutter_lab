// lib/habit_time_model.dart
// HabitTimePlan includes sessions per week for realistic monthly calculation.

class HabitTimePlan {
  final double monthlyMinutes; // total minutes available this month
  final double habitA_minutesPerSession;
  final int habitA_sessionsPerWeek;
  final double habitB_minutesPerSession;
  final int habitB_sessionsPerWeek;
  final double habitC_minutesPerSession;
  final int habitC_sessionsPerWeek;
  final double otherMonthlyMinutes; // other time already as monthly minutes

  HabitTimePlan({
    required this.monthlyMinutes,
    required this.habitA_minutesPerSession,
    required this.habitA_sessionsPerWeek,
    required this.habitB_minutesPerSession,
    required this.habitB_sessionsPerWeek,
    required this.habitC_minutesPerSession,
    required this.habitC_sessionsPerWeek,
    required this.otherMonthlyMinutes,
  });

  /// Convert sessions-per-week and minutes-per-session into monthly minutes.
  /// Uses average weeks per month = 4.345 (52 weeks / 12 months).
  double _monthlyFromSession(double minutesPerSession, int sessionsPerWeek) {
    const double weeksPerMonth = 4.345;
    return minutesPerSession * sessionsPerWeek * weeksPerMonth;
  }

  double get habitA_monthly => _monthlyFromSession(habitA_minutesPerSession, habitA_sessionsPerWeek);
  double get habitB_monthly => _monthlyFromSession(habitB_minutesPerSession, habitB_sessionsPerWeek);
  double get habitC_monthly => _monthlyFromSession(habitC_minutesPerSession, habitC_sessionsPerWeek);

  double get totalUsedMonthly => habitA_monthly + habitB_monthly + habitC_monthly + otherMonthlyMinutes;
  double get remainingMonthly => monthlyMinutes - totalUsedMonthly;
}
