// lib/main.dart
// Habit Calculator (Experiment 4) — "Good Habits" theme
// A simple stateful app that helps you estimate the time commitment
// needed to build habits and gives friendly guidance.

import 'package:flutter/material.dart';

void main() => runApp(const HabitCalculatorApp());

class HabitCalculatorApp extends StatelessWidget {
  const HabitCalculatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Habit Calculator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
      ),
      home: const HabitCalculatorScreen(),
    );
  }
}

/// Experiment heading implemented as a stateful widget (per request).
class ExperimentHeading extends StatefulWidget {
  final String title;
  final String subtitle;
  const ExperimentHeading({super.key, required this.title, required this.subtitle});

  @override
  State<ExperimentHeading> createState() => _ExperimentHeadingState();
}

class _ExperimentHeadingState extends State<ExperimentHeading> {
  bool _showSubtitle = true;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(widget.title, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      subtitle: _showSubtitle ? Text(widget.subtitle) : null,
      trailing: IconButton(
        icon: Icon(_showSubtitle ? Icons.visibility : Icons.visibility_off),
        onPressed: () => setState(() => _showSubtitle = !_showSubtitle),
        tooltip: _showSubtitle ? 'Hide subtitle' : 'Show subtitle',
      ),
    );
  }
}

class HabitCalculatorScreen extends StatefulWidget {
  const HabitCalculatorScreen({super.key});

  @override
  State<HabitCalculatorScreen> createState() => _HabitCalculatorScreenState();
}

class _HabitCalculatorScreenState extends State<HabitCalculatorScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController _numHabitsCtl = TextEditingController(text: '3');
  final TextEditingController _minutesPerHabitCtl = TextEditingController(text: '10');
  final TextEditingController _daysPerWeekCtl = TextEditingController(text: '5');
  final TextEditingController _weeksCtl = TextEditingController(text: '4');

  double? _weeklyMinutes;
  double? _monthlyMinutes;
  double? _dailyAverage;
  String _advice = '';

  @override
  void dispose() {
    _numHabitsCtl.dispose();
    _minutesPerHabitCtl.dispose();
    _daysPerWeekCtl.dispose();
    _weeksCtl.dispose();
    super.dispose();
  }

  void _calculate() {
    if (!_formKey.currentState!.validate()) return;

    final int numHabits = int.tryParse(_numHabitsCtl.text.trim()) ?? 0;
    final double minutesPerHabit = double.tryParse(_minutesPerHabitCtl.text.trim()) ?? 0.0;
    final int daysPerWeek = int.tryParse(_daysPerWeekCtl.text.trim()) ?? 0;
    final int weeks = int.tryParse(_weeksCtl.text.trim()) ?? 0;

    // Protect division by zero
    if (daysPerWeek <= 0 || weeks <= 0 || numHabits <= 0 || minutesPerHabit <= 0) {
      setState(() {
        _weeklyMinutes = null;
        _monthlyMinutes = null;
        _dailyAverage = null;
        _advice = 'Enter positive values for all fields.';
      });
      return;
    }

    final weeklyMinutes = numHabits * minutesPerHabit * daysPerWeek;
    final monthlyMinutes = weeklyMinutes * weeks;
    final dailyAverage = weeklyMinutes / daysPerWeek;

    String advice;
    if (dailyAverage >= 90) {
      advice = 'High commitment — consider reducing minutes or habits.';
    } else if (dailyAverage >= 45) {
      advice = 'Moderate commitment — achievable with discipline.';
    } else {
      advice = 'Manageable — great for consistent habit formation.';
    }

    setState(() {
      _weeklyMinutes = weeklyMinutes;
      _monthlyMinutes = monthlyMinutes;
      _dailyAverage = dailyAverage;
      _advice = advice;
    });
  }

  String? _validatePositiveInteger(String? v) {
    if (v == null || v.trim().isEmpty) return 'This field cannot be empty';
    final parsed = int.tryParse(v.trim());
    if (parsed == null) return 'Enter a valid whole number';
    if (parsed <= 0) return 'Enter a number greater than 0';
    return null;
  }

  String? _validatePositiveNumber(String? v) {
    if (v == null || v.trim().isEmpty) return 'This field cannot be empty';
    final parsed = double.tryParse(v.trim());
    if (parsed == null) return 'Enter a valid number';
    if (parsed <= 0) return 'Enter a number greater than 0';
    return null;
  }

  void _clear() {
    _numHabitsCtl.text = '0';
    _minutesPerHabitCtl.text = '0';
    _daysPerWeekCtl.text = '0';
    _weeksCtl.text = '0';
    setState(() {
      _weeklyMinutes = null;
      _monthlyMinutes = null;
      _dailyAverage = null;
      _advice = '';
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool highCommitment = (_dailyAverage ?? 0) >= 90;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Good Habits — Habit Calculator (Exp 4)'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Experiment heading (stateful)
            const ExperimentHeading(
              title: 'Experiment 4 — Time Estimate',
              subtitle: 'Estimate how much time you need to build your selected habits',
            ),
            const SizedBox(height: 12),

            Form(
              key: _formKey,
              child: Column(
                children: [
                  _buildNumberField(
                    controller: _numHabitsCtl,
                    label: 'Number of habits',
                    hint: 'How many habits you want to build (e.g. 3)',
                    validator: _validatePositiveInteger,
                  ),
                  const SizedBox(height: 10),
                  _buildNumberField(
                    controller: _minutesPerHabitCtl,
                    label: 'Minutes per habit',
                    hint: 'How many minutes each habit takes (e.g. 10)',
                    validator: _validatePositiveNumber,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  ),
                  const SizedBox(height: 10),
                  _buildNumberField(
                    controller: _daysPerWeekCtl,
                    label: 'Days per week',
                    hint: 'How many days per week you will practice (e.g. 5)',
                    validator: _validatePositiveInteger,
                  ),
                  const SizedBox(height: 10),
                  _buildNumberField(
                    controller: _weeksCtl,
                    label: 'Number of weeks to estimate',
                    hint: 'Period length (e.g. 4)',
                    validator: _validatePositiveInteger,
                  ),
                  const SizedBox(height: 18),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _calculate,
                          child: const Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: Text('Calculate Time'),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.grey[300]),
                        onPressed: _clear,
                        child: const Padding(
                          padding: EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                          child: Text('Clear', style: TextStyle(color: Colors.black87)),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Result card
            if (_weeklyMinutes != null)
              Card(
                elevation: 3,
                margin: const EdgeInsets.symmetric(vertical: 8),
                child: Padding(
                  padding: const EdgeInsets.all(14.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('Summary', style: TextStyle(fontSize: 16, color: Colors.black87)),
                          const SizedBox(height: 8),
                          Text('Weekly time: ${_weeklyMinutes!.toStringAsFixed(0)} mins',
                              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 6),
                          Text('Estimated over period: ${_monthlyMinutes!.toStringAsFixed(0)} mins',
                              style: const TextStyle(fontSize: 14, color: Colors.black54)),
                          const SizedBox(height: 8),
                          Text('Daily average (on practice days): ${_dailyAverage!.toStringAsFixed(1)} mins',
                              style: TextStyle(fontSize: 14, color: highCommitment ? Colors.red : Colors.green[700])),
                          const SizedBox(height: 8),
                          Text(_advice, style: TextStyle(fontSize: 14, color: highCommitment ? Colors.red : Colors.green)),
                        ]),
                      ),
                      const SizedBox(width: 12),
                      Icon(
                        highCommitment ? Icons.timer_off_rounded : Icons.self_improvement_rounded,
                        size: 44,
                        color: highCommitment ? Colors.red : Colors.teal,
                      ),
                    ],
                  ),
                ),
              ),

            const SizedBox(height: 12),

            // Helpful tips
            Card(
              color: Colors.teal.shade50,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(children: const [
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: Icon(Icons.lightbulb_outline),
                    title: Text('Pro tip'),
                    subtitle: Text(
                        'Start small. It\'s better to reliably do 5 minutes than rarely do 60. Build consistency first.'),
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNumberField({
    required TextEditingController controller,
    required String label,
    String? hint,
    String? Function(String?)? validator,
    TextInputType? keyboardType,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType ?? const TextInputType.numberWithOptions(decimal: false),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
        contentPadding: const EdgeInsets.symmetric(vertical: 12.0, horizontal: 12.0),
      ),
      validator: validator,
    );
  }
}
